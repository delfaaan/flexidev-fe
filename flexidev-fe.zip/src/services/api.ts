const BASE_URL = 'https://swapi.dev/api';

export const fetchCharacters = async () => {
	const response = await fetch(`${BASE_URL}/people/`);

	const data = await response.json();

	return data;
};

export const fetchCharacter = async (id: number) => {
	const response = await fetch(`${BASE_URL}/people/${id}`);

	const data = await response.json();

	return data;
};

export const fetchResource = async (url: string) => {
	const response = await fetch(url);

	const data = await response.json();

	return data;
};