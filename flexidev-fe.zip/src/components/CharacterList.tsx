import React, { useEffect, useState } from 'react';
import { fetchCharacters } from '../services/api';
import { ApiResponse, Character } from '../types/types';

const CharacterList: React.FC = () => {
	const [characters, setCharacters] = useState<Character[]>([]);

	useEffect(() => {
		const getCharacters = async () => {
			const data = await fetchCharacters();

			setCharacters((data as ApiResponse<Character>).results);
		};

		getCharacters();
	}, []);

	return (
		<div>
			<h1>Star Wars Characters</h1>
			<ul>
				{characters.map((character) => (
					<li key={character.url}>
						<a href={`/character/${character.url.split('/').filter(Boolean).pop()}`}>
							{character.name}
						</a>
					</li>
				))}
			</ul>
		</div>
	);
};

export default CharacterList;